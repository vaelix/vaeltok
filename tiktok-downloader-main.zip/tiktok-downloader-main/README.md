<h1 style="align: center;">Tiktok Downloader</h1>

<h2>Installation</h2>
run in your terminal:

```
git clone https://github.com/n0l3r/tiktok-downloader.git
cd tiktok-downloader
npm i
node index
```
